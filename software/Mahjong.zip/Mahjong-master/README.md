# Mahjong
Mahjong Solitaire is a classic Chinese game. The goal of the game is to remove all 144 tiles from the board. 
You may only remove paired free tiles. 
